import 'package:flutter/material.dart';

class AppColor {
  //onboarding screen Controller color
  static const Color oncontainer = Color(0xFFFF9800);
  // Background color
  static const Color background = Colors.white;

  // Main button (primary)
  static const Color buttonOrange = Color(0xFFFF9800); // dark orange

  // Secondary / option button (low orange)
  static const Color buttonLightOrange =
      Color(0xffFFD8C7); // light orange shade

  // Text colors
  static const Color textBlack = Colors.black;
  static const Color textGrey = Colors.grey;
  static const Color textWhite = Colors.white;
}
