import 'package:clickcart/view/profile/widget/membership.dart';
import 'package:clickcart/view/profile/widget/profileappbar.dart';
import 'package:clickcart/view/profile/widget/profileimage.dart';
import 'package:clickcart/view/profile/widget/profilewidget.dart';
import 'package:flutter/material.dart';

import '../../../utilitis/textstyel.dart';

class Profile extends StatelessWidget {
  const Profile({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: EdgeInsets.only(left: 15, right: 15),
        child: Column(
          //crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 35),
            Profileappbar(),
            SizedBox(height: 15),
            Profileimage(),
            SizedBox(height: 15),
            Membership(),
            SizedBox(height: 20),
            Row(
              children: [
                Text("Account Settings", style: CommonTextStyle.bold),
              ],
            ),
            SizedBox(height: 10),
            Profilewidget(),
          ],
        ),
      ),
    );
  }
}
