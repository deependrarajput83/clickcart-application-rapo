import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../controller/homepagecontroller/homepagecontroller.dart';
import '../../../../utilitis/textstyel.dart';
import 'moreproduct.dart';

class FashionCategoryDatils extends StatelessWidget {
  FashionCategoryDatils({super.key});
  SizesC selectedcon = Get.put(SizesC());
  Bottombutton bottombutton = Get.put(Bottombutton());
  List<String> Clothsize = ["XS", "S", "M", "L", "XL", "XXL"];
  List<Color> ClothColor = [
    Colors.cyan,
    Colors.red,
    Colors.blue,
    Colors.orange,
    Colors.yellow,
    Colors.deepOrange
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Stack(
              children: [
                SizedBox(height: 10),
                Container(
                  height: Get.height * 0.5,
                  width: double.infinity,
                  decoration: BoxDecoration(color: Colors.white),
                  child: ClipRRect(
                    child: Image.asset(
                      "assets/fashion/t-shrt.png",
                      height: Get.height * 0.3,
                      width: Get.width * 0.4,
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
                Positioned(
                  top: 30,
                  left: 10,
                  right: 10,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                          onPressed: () {
                            Get.back();
                          },
                          icon: Icon(Icons.arrow_back)),
                      Container(
                        height: Get.height * 0.05,
                        width: Get.width * 0.2,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.grey.shade500)),
                        child: Center(
                          child: IconButton(
                              onPressed: () {},
                              icon: Icon(Icons.favorite_border_outlined)),
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 8, 15, 0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Text(
                      "Men's outfitter t-shirt",
                      style: CommonTextStyle.Details,
                    ),
                    Spacer(),
                    Text(
                      "₹ 200",
                      style: CommonTextStyle.Details,
                    )
                  ]),
                  SizedBox(height: 10),
                  Row(
                    children: [
                      Icon(
                        Icons.star,
                      ),
                      Text(
                        "4.8",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        width: 8,
                      ),
                      Text("(3.2k reviews)"),
                      SizedBox(
                        width: Get.width * 0.25,
                      ),
                      Container(
                        height: Get.height * 0.028,
                        width: Get.width * 0.22,
                        decoration: BoxDecoration(
                            color: Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(5)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text(
                              "20,343",
                            ),
                            Text("solt")
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: Get.height * 0.02,
                  ),
                  Divider(
                    thickness: 0.5,
                  ),
                  SizedBox(
                    height: Get.height * 0.01,
                  ),
                  Text("Sizes", style: CommonTextStyle.Details),
                  Obx(
                    () => Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: List.generate(6, (index) {
                          bool isSelected =
                              selectedcon.selectedSizeIndex.value == index;
                          return Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: GestureDetector(
                              onTap: () {
                                selectedcon.selectedSizeIndex(index);
                              },
                              child: Container(
                                height: 28,
                                width: 45,
                                decoration: BoxDecoration(
                                    color: isSelected
                                        ? Colors.orange
                                        : Colors.white,
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        color: Colors.grey.shade200)),
                                child: Center(child: Text(Clothsize[index])),
                              ),
                            ),
                          );
                        })),
                  ),
                  SizedBox(
                    height: Get.height * 0.01,
                  ),
                  Text("Color", style: CommonTextStyle.Details),
                  Obx(
                    () => Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: List.generate(6, (index) {
                          bool isSelected =
                              selectedcon.selectedColorIndex.value == index;
                          return Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: GestureDetector(
                              onTap: () {
                                selectedcon.selectedColorIndex(index);
                              },
                              child: Container(
                                height: 28,
                                width: 45,
                                decoration: BoxDecoration(
                                    color: ClothColor[index],
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                        color: isSelected
                                            ? Colors.black
                                            : Colors.white,
                                        width: 2)),
                              ),
                            ),
                          );
                        })),
                  ),
                  Text(
                    "Description",
                    style: CommonTextStyle.Details,
                  ),
                  Text(
                    "Homegrown Indian Brand - One-stop-shop for Official Merch of all your favorite superheroes, films, TV shows and cartoons"
                    "Versatile Wardrobe Essential: Perfect for casual outings. Suitable for various activities and everyday wear."
                    "Embrace a blend of comfort and fashion with these Trendy Outfits"
                    "High Definition Print - Using the highest quality solvents and colors",
                    style: CommonTextStyle.small,
                  ),
                  SizedBox(
                    height: Get.height * 0.02,
                  ),
                  Text(
                    "Review and rating",
                    style: CommonTextStyle.Details,
                  ),
                  Obx(
                    () => Row(
                        mainAxisSize: MainAxisSize.min,
                        children: List.generate(5, (index) {
                          bool isSelectedStar =
                              index <= selectedcon.selectedStarIndex.value;
                          return IconButton(
                              onPressed: () {
                                selectedcon.selectStar(index);
                              },
                              icon: Icon(Icons.star,
                                  color: isSelectedStar
                                      ? Colors.orange
                                      : Colors.grey));
                        })),
                  ),
                  SizedBox(
                    height: Get.height * 0.01,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [Text("Read all Comment"), Icon(Icons.reviews)],
                  ),
                  SizedBox(
                    height: Get.height * 0.02,
                  ),
                  Text(
                    "More product",
                    style: CommonTextStyle.Details,
                  ),
                  Fashiontabmore()
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        height: 55,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
        ),
        child: Row(
          children: [
            GestureDetector(
              onTap: () {
                bottombutton.decrement();
              },
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.grey.shade300,
                child: Icon(Icons.remove),
              ),
            ),
            Obx(
              () => Text("${bottombutton.additem.value}",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            GestureDetector(
              onTap: () {
                bottombutton.incerment();
              },
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.grey.shade300,
                child: Icon(Icons.add),
              ),
            ),
            ElevatedButton(
              onPressed: () {},
              child: Text(
                "Add to Cart",
                style:
                    TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                padding: EdgeInsets.symmetric(vertical: 20, horizontal: 40),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50)),
              ),
            )
          ],
        ),
      ),
    );
  }
}
